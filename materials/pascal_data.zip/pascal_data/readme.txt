  This package provides annotations of pose joint locations and semantic part segmentation masks for the dataset PASCAL-Person-Part. PASCAL-Person-Part includes 3533 human images from PASCAL VOC 2010, which has large variation of human poses, scales and occlusion.
  
  

[Data Use]
  The images of PASCAL-Person-Part can be downloaded from the PASCAL VOC website. We recommend to use images in 'train_id.txt' for training and images in 'val_id.txt' for testing.
  
  Pose annotations are under the directory "PersonJoints/". Every image has its corresponding '.mat' annotation file, containing the joint locations of people appearing in the image. Specifically, each '.mat' file contains 'boxes' and 'joints'. 'boxes' are a list of cells corresponding to human bounding boxes in the image (order: left column, up row, right column, bottom row). 'joints' are also a list of cells giving the position of joints for each human instance. Each cell of 'joints' is a 14*3 matrix, giving column position, row position, and visibility (1: visible; 2: can be reliably estimates; 0: occluded) for 14 joint types (i.e. forehead, neck, left shoulder, left elbow, left wrist, left hip, left knee, left ankle, right shoulder, right elbow, right wrist, right hip, right knee, and right ankle).
  
  Part annotations are under the directory "SegmentationPart/". Every image has its corresponding '.png' annotation file, containing pixel-wise part labels. The parts we have annotated are: background (id: 0), head (id: 1), torso (id: 2), upper-arm (id: 3), lower-arm (id: 4), upper-leg (id: 5), and lower-leg (id: 6). If you want more detailed parts like eyes and nose, please refer to the PASCAL-Part Dataset, which contains part masks for multiple object categories: http://www.stat.ucla.edu/~xianjie.chen/pascal_part_dataset/pascal_part.html.
  
           
		   
[Citation]
  If you use our annotations, please consider citing the following papers.
  
    [1] "Joint Multi-Person Pose Estimation and Semantic Part Segmentation"
	    Fangting Xia, Peng Wang, Xianjie Chen, Alan Yuille
	    IEEE Conference on Computer Vision and Pattern Recognition (CVPR), 2017
		
	[2] "Detect What You Can: Detecting and Representing Objects using Holistic Models and Body Parts"
	    Xianjie Chen, Roozbeh Mottaghi, Xiaobai Liu, Sanja Fidler, Raquel Urtasun, Alan Yuille
	    IEEE Conference on Computer Vision and Pattern Recognition (CVPR), 2014
		